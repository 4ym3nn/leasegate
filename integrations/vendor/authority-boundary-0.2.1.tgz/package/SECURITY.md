# Security policy

Version 0.2.x is a private evaluation line. There is no support SLA or completed independent security audit. Report suspected vulnerabilities through a private channel agreed with the repository owner; do not post grant values, keys or sensitive findings in public issues.

The trusted computing base includes the issuer, key distribution, policy engine, claim store, audit sink and protected application code. The SDK does not sandbox a compromised worker or authenticate a user on the host's behalf.

Before deployment, review the [threat model](docs/THREAT_MODEL.md) and [operations guide](docs/OPERATIONS.md), validate your policy mapping, configure durable shared claims, protect signing keys, test failure recovery and arrange independent review appropriate to the deployment's risk.

Security fixes require regression tests. Dependency audit results and passing tests are evidence with a limited scope; neither establishes absence of vulnerabilities.
