# Changelog

## 0.2.1

- Keep distributed documentation focused on SDK usage, architecture and operations.
- Standardize punctuation in documentation and validation messages.

## 0.2.0

- Introduce version 2 JWS grants binding canonical operation parameters; reject version 1 grants.
- Snapshot and freeze approval and execution data.
- Align replay retention with acceptance tolerance and recheck expiry before effects.
- Add bounded dependency calls and runtime contract validation.
- Separate completed-but-unaudited results from effect exceptions.
- Use `jose` for Ed25519 JWS verification.
- Add PostgreSQL atomic claims and durable audit, with real worker/process/restart checks.
- Pin OpenFGA models and request higher-consistency checks with tenant-scoped names.
- Integrate a durable export queue and an official MCP SDK stdio server.
- Add fixed-endpoint JWKS rotation and privacy-conscious OpenTelemetry wrappers.
- Reject array accessors, hidden extensions and sparse parameter arrays.
- Add independent package-consumer checks, Node 22/24 CI, reproducible latency samples and operational recovery documentation.

See [migration notes](docs/MIGRATION.md) for breaking changes from the prototype.

## 0.1.0 (unreleased)

- Add Ed25519-signed delegated authorization grants.
- Bind grants to an issuer, audience, subject, tenant, action, resource, purpose, and lifetime.
- Recheck application policy at execution time.
- Add consume-once replay protection and structured audit events.
- Add a reference background-worker integration and threat model.
- Add a configurable OpenFGA policy adapter.
