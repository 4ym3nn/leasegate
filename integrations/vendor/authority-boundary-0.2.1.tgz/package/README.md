# Authority Boundary

Execution-time authorization for AI tools and background jobs. A short-lived Ed25519 grant binds the subject, tenant, action, resource, audience and operation parameters. The guard verifies the grant, rechecks current policy, atomically consumes it, and records authorization before calling the protected effect.

Includes PostgreSQL/OpenFGA queue and MCP integrations, key rotation, telemetry and an installable TypeScript SDK. The API is pre-1.0. See [SECURITY.md](SECURITY.md) for deployment considerations.

## Why it exists

A document export may be approved when queued, then run after the user's permission is removed. An agent may also change the document or destination between approval and execution. Authority Boundary checks the exact approved operation at the execution boundary and asks the policy system again.

The host application authenticates the user and establishes approval before issuance. The SDK does not infer consent from an LLM response. The signed grant is itself a narrow, single-use bearer capability: protect it in queues, MCP metadata and logs.

## Run it

Requires Node.js >=22.13, pnpm 10.18, and Docker Compose for live examples. CI tests Node.js 22 and 24.

```bash
pnpm install --frozen-lockfile
pnpm verify
pnpm demo

pnpm services:up
pnpm test:integration
pnpm demo:worker
pnpm demo:mcp
pnpm test:durability
pnpm benchmark
pnpm services:down
```

The Compose fixtures bind to loopback: PostgreSQL on 55439 and OpenFGA on 18089. Credentials are synthetic, local-only values. The durability check restarts this project's PostgreSQL container. Stopping services preserves their named volume. Examples create synthetic stores, jobs and export receipts in that volume.

The worker persists a JSON export, then rejects a queued export after permission deletion. The MCP example starts a separate server using the official MCP SDK over stdio and exercises the same protected export operation. No model account or API key is needed.

## Integrate

Implement `PolicyEngine.check` with your application's policy system, or use the included OpenFGA adapter. Configure an issuer with its private key and a guard with trusted verification keys, a shared claim store and an audit sink.

```ts
const token = await issuer.issue({
  subject: authenticatedSubject,
  action: "document.export",
  resource: { type: "document", id: "report", tenantId: "acme" },
  parameters: { format: "json" },
  purpose: "User approved report export",
  lifetimeSeconds: 60,
});

const receipt = await guard.run(
  {
    token,
    actor: "worker:export", // fixed by the authenticated host
    action: "document.export",
    resource: { type: "document", id: "report", tenantId: "acme" },
    parameters: { format: "json" },
  },
  async (approved) => exportDocument(approved),
);
```

This illustrates the call contract; [the complete memory example](examples/background-export.ts) and [live setup](examples/support/runtime.ts) construct every dependency. The protected callback must use the immutable `approved` values. Include every security-relevant argument, such as destination, amount or object version, in `parameters`.

Use `PostgresExecutionClaimStore` and `PostgresAuditSink` with a host-owned `pg.Pool` for shared durable storage. The in-memory implementations are for single-process evaluation. MCP hosts put grants in request `_meta["io.authority-boundary/grant"]`, outside the model-visible input schema.

`pnpm test:package` builds and installs the archive into a separate consumer project, checks its TypeScript declarations and runs a signed operation. Authorized collaborators can install the resulting private archive:

```bash
npm install /path/to/authority-boundary-0.2.1.tgz
```

## Guarantees and limits

The guard requires exact signed bindings, acceptable time, live policy approval, an atomic claim, and acknowledged pre-effect audit. Dependency errors prevent the callback from starting. Default clock tolerance is zero; grant lifetime defaults to a maximum of 300 seconds.

This is at-most-once admission per grant with a correctly shared claim store, not exactly-once completion. An effect can partially complete and throw. A completion-audit error preserves the successful result. Neither case is automatically retried. Policy can change between the last check and the effect; transactional revocation requires enforcement in the resource service.

See [architecture](docs/ARCHITECTURE.md), [threat model](docs/THREAT_MODEL.md), [operations and recovery](docs/OPERATIONS.md), [evaluation](docs/EVALUATION.md) and [migration notes](docs/MIGRATION.md).
