# ADR 0002: Use a narrowly bound signed grant

Status: accepted; updated for version 2

## Context

Passing a user's upstream bearer token through queues expands credential exposure. Unsigned metadata permits substitution; a signed resource identifier alone does not bind operation arguments.

## Decision

Use an Ed25519 JWS with an exact issuer, audience, subject, tenant, action, resource, purpose, grant ID and validity interval. Version 2 adds SHA-256 of bounded canonical JSON parameters. Use jose for cryptographic operations and allow only Ed25519 keys and the restricted protected header. Reject older grant versions.

The host establishes approval; the token attests to the issuer's assertion and is not proof of a human interaction. The grant is a narrow bearer capability and remains insufficient without current policy approval and atomic admission.

## Consequences

Workers avoid upstream user credentials, but must protect grants. Public-key distribution and private-key lifecycle remain trusted. Every security-relevant execution input must be bound and used from the verified callback snapshot. Resource versions must be bound if mutable content matters to approval. Cross-language canonicalization and multi-hop delegation are outside this release.
