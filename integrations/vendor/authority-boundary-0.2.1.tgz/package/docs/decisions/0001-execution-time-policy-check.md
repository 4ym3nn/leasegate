# ADR 0001: Recheck policy at execution time

Status: accepted

## Context

Permissions can change while work waits in a queue or agent runtime. Treating issuance-time authorization as durable authority creates stale-access windows after membership removal, role downgrade, or resource transfer.

## Decision

The guard asks the host application's policy engine to authorize the original subject immediately before every protected effect. Policy errors deny execution.

## Consequences

Revocation behavior follows the policy engine's consistency guarantees. The execution path gains a runtime dependency on that engine. Applications must select an availability strategy explicitly; this SDK does not fall back to the issuance-time result.
