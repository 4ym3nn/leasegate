# Architecture

Authority Boundary separates a signed attestation of an approved operation from the current policy decision. Authentication and approval belong to the host application.

```mermaid
sequenceDiagram
    participant H as Authenticated host
    participant I as Issuer
    participant Q as Queue or MCP host
    participant G as Guard
    participant P as Policy
    participant D as Claims and audit
    participant E as Protected effect
    H->>I: Exact approved operation
    I->>P: Initial policy check
    I->>D: Persist issuance audit
    I-->>Q: Signed version 2 grant
    Q->>G: Grant and requested operation
    G->>G: Verify signature, bindings and time
    G->>P: Recheck original subject's permission
    G->>G: Recheck time
    G->>D: Atomic claim, then authorization audit
    G->>G: Recheck time
    G->>E: Immutable verified values
    E-->>G: Durable receipt or exception
    G->>D: Completion or uncertain-effect audit
```

## Core contract

`DelegationIssuer` uses Ed25519 through `jose`. Version 2 claims contain grant ID, issuer, audience, subject, action, resource, purpose, issue/not-before/expiry timestamps and SHA-256 of canonical parameters. The protected JWS header permits only alg, kid and typ. Verification keys are selected from configured trust sources, never a token-provided URL.

Parameters are finite JSON, recursively snapshotted and frozen, with sorted object keys. Limits are 16 KiB serialized, 4096 visited values and depth 32. Unsupported values fail before authorization. The serialized token is also bounded to 16 KiB. Field strings have explicit bounds. This canonicalization contract is implemented for the Node SDK; it is not a claim of interoperability with an external canonical JSON standard.

`AuthorizationGuard.run` compares exact action, resource type/ID/tenant and parameter digest. It verifies subject/resource tenant equality, pinned issuer/audience and time before and after awaited pre-effect work. Policy must return a literal boolean. Version 1 grants are rejected.

Policy, key resolution, claims and audit have bounded waits. These deadlines do not cancel an underlying database operation: a timed-out claim can still commit. Effects have no automatic timeout or retry because interruption cannot prove rollback.

## Durable admission and audit

The claim key hashes issuer, audience and grant ID. PostgreSQL arbitrates claims through a unique constraint; only one successful insertion admits execution. Claims are retained indefinitely by default. In-memory claims include the configured tolerance in retention, but must not coordinate multiple processes.

An acknowledged authorization audit is required before the callback. Issuance also requires acknowledged audit before returning a grant. Denial audit is best effort; malformed inputs and audit outages can leave no denial record. Audit events omit raw tokens and parameters but retain subject, resource and purpose data.

Claim, audit and application effect are separate operations. A failure after claiming can consume a grant without executing. `EffectExecutionError` means the effect threw and its outcome may be partial. `CompletionAuditError` means the callback returned successfully and carries its result for reconciliation.

## Adapters and reference application

The OpenFGA adapter pins a model ID, requests HIGHER_CONSISTENCY and uses an explicit host-supplied mapping. `tenantScopedObject` creates unambiguous tenant/ID names. Every relation and data lookup must use the same namespace convention.

The queue selects jobs atomically using SKIP LOCKED; claimed jobs left after crashes require reconciliation. The official MCP SDK runs a separate stdio tool server with fixed actor/action and metadata grants. Both integrations call the same database export function, which uses only approved values and records a receipt keyed by grant ID.

Remote JWKS provides bounded, cached public-key discovery. Optional OpenTelemetry wrappers observe policy and audit without attaching identity, tokens, parameters or policy reasons. Telemetry is supplementary; the audit sink remains authoritative.
