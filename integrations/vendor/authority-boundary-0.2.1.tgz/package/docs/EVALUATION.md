# Evaluation

Run `pnpm verify` for formatting, TypeScript, unit/protocol tests and installation of the packed ESM SDK in a separate consumer. Run `pnpm test:coverage` for Node's unit-suite coverage report. Coverage excludes the separate integration run; it is not a security score.

With `pnpm services:up`, run `pnpm test:integration` against actual PostgreSQL and OpenFGA. Tests cover independent processes and connections, concurrent claims, same-name tenant separation, revocation, durable exports and official MCP client/server calls. `pnpm test:durability` restarts the dedicated database and reconstructs the worker before attempting replay. It tests graceful restart, not power loss or failover.

CI repeats these checks on Node.js 22 and 24 and uploads the private package and benchmark artifacts. Container images and CI actions are pinned; pnpm installs the committed lockfile. `pnpm audit --audit-level=high` checks published dependency advisories at run time, not all possible vulnerabilities.

## Latency methodology

`pnpm benchmark` records 200 sequential samples after 20 warmups per scenario. Set BENCH_SAMPLES between 20 and 10000 to change the sample count. The effect is a no-op; the live path includes real loopback policy, claim and synchronous audit operations.

- Memory policy baseline and guard with pre-issued tokens.
- Live OpenFGA policy baseline.
- Live issuance plus execution, including their audits.
- Live guard execution, excluding issuance.
- One denied execution after an acknowledged tuple deletion.

The report records all raw samples, nearest-rank percentiles, environment, Git revision and a SHA-256 digest of sorted source filenames and contents. The baseline checks policy only; it is not an equivalent alternative authorization system. Results do not establish throughput, production latency, scalability or a revocation SLA. The single revocation measurement times a denial check after deletion; it is not a statistical distribution of propagation delay.

Output is `artifacts/benchmark.json`. Maintainers can run `pnpm benchmark --record` to save a reviewable snapshot in `docs/evaluation/benchmark.json`. Confirm that the source digest matches the reviewed code; a documentation-only commit may follow the recorded Git revision. Compare like environments and workloads, not isolated headline percentiles.

## Recorded local baseline

The [raw snapshot](evaluation/benchmark.json) records source revision `014e3b2`, Node.js 26.7.0 on Linux x64, Intel Core i7-14650HX, 200 samples and 20 warmups. Source digest: `c90d7855e925a0c5fd0a839adb76709212b1bc1c034e871ad5010f350bb8097f`.

| Scenario                    | p50 ms | p95 ms | p99 ms |
| --------------------------- | -----: | -----: | -----: |
| Memory guard                |  0.298 |  0.563 |  0.694 |
| Live policy only            |  2.317 |  3.218 |  3.571 |
| Live guard execution        | 10.220 | 13.876 | 16.762 |
| Live issuance and execution | 17.283 | 21.511 | 27.736 |

The single post-deletion check denied execution in 7.671 ms. The same revision passed 51 unit/protocol tests, 15 live integration tests, package-consumer verification, restart replay checking and both live demos. Unit-suite coverage was 93.97% lines and 86.33% branches; live integration coverage is not included in those percentages. The dependency audit reported no known advisories at the time of this run.

## Limitations

This evaluation does not cover concurrent load, capacity limits, database failover or deployment-specific recovery. The implementation has not undergone an independent security audit.
