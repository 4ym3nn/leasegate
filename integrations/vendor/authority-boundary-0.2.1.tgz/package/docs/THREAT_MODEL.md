# Threat model

## Scope and assumptions

A trusted host authenticates a subject, establishes approval and issues a narrowly bound grant. A lower-trust queue or agent runtime transports it to a trusted service. An adversary may alter job fields, tool arguments, ordering and retries, or possess a grant. The issuer key, key source, policy service, database and guarded application code are trusted.

The SDK is a library inside the service, not a sandbox. Every route to the protected operation must enforce the same boundary. A worker with direct resource credentials can bypass a library if compromised.

## Controls

| Threat                                    | Control                                                       | Required application condition                                                               |
| ----------------------------------------- | ------------------------------------------------------------- | -------------------------------------------------------------------------------------------- |
| Action, resource or argument substitution | Exact signature and parameter digest checks                   | Bind every security-relevant argument; use approved callback values                          |
| Cross-tenant confused deputy              | Tenant equality plus tenant-scoped policy names               | Scope policy objects, users and database reads consistently                                  |
| Use at another service                    | Pinned issuer and audience                                    | Distinct service audiences and trusted verification configuration                            |
| Revocation while queued                   | Live execution-time policy check                              | Policy source reflects the change; resource service enforces stronger transactions if needed |
| Replay or racing workers                  | Shared atomic claim before callback                           | All replicas use the same durable claim store                                                |
| Tampering or algorithm confusion          | Restricted JWS header, Ed25519-only keys, canonical encodings | Protect issuer keys and key distribution                                                     |
| Dependency outage                         | Bounded waits and fail-closed admission                       | Host does not catch denial and execute through another path                                  |
| Missing execution evidence                | Required pre-effect audit and typed completion outcomes       | Durable audit storage and reconciliation                                                     |

## Residual risks

- A stolen grant can be used first by its holder for the exact operation while policy permits it. Actor is host-supplied attribution, not cryptographic presenter binding.
- A compromised signing key can mint grants until every verifier stops accepting it. JWKS cache windows delay removal; see operations.
- Authorization and the effect are not one transaction. Permission can change after a successful check. HIGHER_CONSISTENCY does not establish universal or cross-system linearizability.
- Resource names can be reused or content can change. Use immutable IDs and bind a version where approval concerns particular content; validate that version inside the effect.
- Claims provide at-most-once admission per grant, not once per business operation. A newly issued grant can authorize the same operation again.
- Effects may partially complete before throwing. Process crashes can leave claims and jobs in uncertain states. Completion-audit failures cannot undo an effect.
- Clock correctness and database durability depend on the deployment. Database loss or premature claim deletion can re-enable a still-valid grant.
- Token and parameter size limits are not rate limiting. Hosts need authentication, request limits and admission controls to resist resource exhaustion.
- Signed grants are readable, not encrypted. Audit identities and purpose may be sensitive even though raw grants and parameters are omitted.
- No per-grant cancellation list or multi-hop delegation protocol is included. Policy revocation and key removal have different scopes and timing.

Tests exercise these controls and selected failures. Coverage does not establish that every failure mode or bypass has been excluded.
