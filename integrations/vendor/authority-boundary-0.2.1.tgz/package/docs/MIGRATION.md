# Migrating from the 0.1 prototype

Version 0.2 intentionally breaks the prototype contract; the API is pre-1.0.

- Version 1 tokens are rejected. Drain or invalidate old queued work and issue fresh version 2 grants after approval and policy checks.
- Security-relevant arguments now belong in `parameters` on both issue and execution requests. Omitted parameters mean an empty object.
- `signDelegation` is asynchronous. Prefer the issuer API; raw signing and verification helpers do not enforce the full execution contract.
- OpenFGA configuration requires an explicit authorization model ID. Migrate tuple names and mappings together when using tenant-scoped identifiers.
- Default clock tolerance is zero. Configure tolerance deliberately and retain claims through the complete acceptance window.
- Handle `CompletionAuditError` separately from `EffectExecutionError` and `AuthorizationError`. Do not reinterpret a completed effect as safe to retry.
- Use PostgreSQL claims shared across every worker. In-memory claim state is lost on restart.
- Install the private packed ESM package rather than assuming CommonJS support or a public npm publication.

There is no rolling compatibility between version 1 and version 2 grants. Review the architecture and operations guide before replacing a running prototype.
