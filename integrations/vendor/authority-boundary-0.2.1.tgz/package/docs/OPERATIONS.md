# Operations and recovery

## Deploy the trust boundary

Authenticate subjects and establish approval before calling the issuer. Generate signing keys outside source control; the issuer accepts an Ed25519 PKCS#8 PEM. Use distinct key IDs and a configured issuer/audience per trust domain. Workers receive SPKI public keys or a fixed JWKS endpoint, never the private key.

Install the packed ESM SDK on Node.js >=22.13. Supply a policy adapter, durable shared claims and audit. Run `initializePostgres(pool)` once with a deployment role before starting replicas. The runtime role needs schema USAGE, INSERT on claims and audit, and SELECT on the claims table's claim_key column for conflict handling and RETURNING; it does not need schema creation, UPDATE or DELETE for the SDK tables. Use a trusted schema/search_path. Grant separate, minimal privileges for your application's effect and queue tables. Configure connection/query timeouts, TLS, backups and disk monitoring in the host-owned database pool. The SDK does not manage migrations for your business schema.

OpenFGA requires a pinned store and model ID. Map the subject and object through `tenantScopedObject`; use fixed, explicitly allowed relations for actions. Populate tuples using the same mapping. Contextual tuples must come from trusted application state, not model-generated input. The adapter rejects redirects and non-HTTPS endpoints except loopback.

## Key rotation

1. Publish the new Ed25519 public key under a new kid alongside the old key.
2. Refresh each verifier and confirm it can resolve the new key before switching issuers. Unknown keys can be temporarily rejected during the configured refresh cooldown.
3. Switch issuers to the new signing key.
4. Keep the old verification key until old grants expire, including configured tolerance. Then remove it and refresh all verifiers.

`RemoteJwksResolver` defaults to a 30-second cache, 2-second fetch deadline and 1-second cooldown. `await resolver.reload()` forces a fetch. Removal is not instantaneous across caches. For compromise response, remove the key, force and verify refresh on every replica, and suspend admission on any replica whose key state cannot be confirmed. An unsuccessful manual reload does not itself erase an otherwise fresh cache. Never reuse a kid for different key material.

Keep clocks synchronized. Tolerance defaults to zero and can extend acceptance by up to 60 seconds when explicitly configured. Issuer and verifier have independent maximum-lifetime configuration.

## Failure recovery

| Result                         | Effect status                               | Required response                                                                  |
| ------------------------------ | ------------------------------------------- | ---------------------------------------------------------------------------------- |
| Successful return              | Callback completed                          | Store/use its receipt                                                              |
| AuthorizationError             | Guard did not call the effect               | Inspect code; grant may already be consumed after claim or audit uncertainty       |
| EffectExecutionError           | Callback threw; partial completion possible | Reconcile using grant ID and application receipt before considering fresh approval |
| CompletionAuditError           | Callback completed                          | Preserve `result`, repair missing audit; do not repeat effect                      |
| Process crash or lost response | Unknown                                     | Reconcile durable business state, claim and audit records                          |

Do not implement blanket retries around `guard.run`. An unused, denied grant can still expire or become invalid before a later attempt. A claim timeout may commit in the database after the guard has returned. The reference queue leaves claimed jobs after a crash for operator reconciliation; it is not a complete production scheduler.

Claim rows are retained indefinitely. Plan storage capacity. Any cleanup must wait beyond the latest acceptance time across all verifiers and maximum clock lag; `retain_until` alone is not permission for an unsynchronized cleaner to delete rows. Restoring an old database snapshot while accepting old grants can also permit replay.

Audit events have UUID event IDs and grant IDs. Required events precede admission; a failed or timed-out completion write can leave a missing or late event. Denial audit is best effort. Logs must never include token values, private keys or full queued payloads. Configure retention and access controls for identities, resource IDs and purpose strings.

## Telemetry

Wrap the policy with `instrumentPolicy(policy, { tracer, meter })` and the audit sink with `instrumentAudit(audit, { tracer, meter })`. Configure providers/exporters in the host. The wrappers emit policy duration, outcomes and audit persistence counts; they omit identity, token, parameters, policy reason and exception text. Telemetry emission errors do not permit execution or replace durable audit. Monitor dependency error rates, denial rates, claim-table growth and reconciliation backlog.

## MCP transport

The included server uses local stdio. A production HTTP MCP service needs its own transport authentication, tenant resolution, rate limits and secrets handling. The host supplies the grant in request metadata, fixes the service actor at registration and treats model arguments as untrusted. Metadata is still sensitive bearer material; avoid exposing it in model context or protocol logs.

The reference completion response reports `completed_audit_pending` with a receipt and `retry: false`. Preserve that distinction when adapting errors to your own protocol.
